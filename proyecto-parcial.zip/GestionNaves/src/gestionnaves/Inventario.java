package gestionnaves;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public class Inventario<T extends Comparable<T>> {
    private List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public void paraCadaElemento(java.util.function.Consumer<T> accion) {
        elementos.forEach(accion);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public void ordenar() {
        elementos.sort(Comparable::compareTo);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public void guardarEnArchivo(String nombreArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeObject(elementos);
        }
    }

    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    public void guardarEnCSV(String nombreArchivo) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(nombreArchivo))) {
            for (T elemento : elementos) {
                if (elemento instanceof NaveEspacial) {
                    writer.println(((NaveEspacial) elemento).toCSV());
                }
            }
        }
    }

    public void cargarDesdeCSV(String nombreArchivo, java.util.function.Function<String, T> fromCSV) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                elementos.add(fromCSV.apply(linea));
            }
        }
    }
}
