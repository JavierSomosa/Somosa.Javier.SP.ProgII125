package gestionnaves;

import java.io.Serializable;

public class NaveEspacial implements Serializable, Comparable<NaveEspacial> {
    private int id;
    private String nombre;
    private int capacidad;
    private Categoria categoria;

    public NaveEspacial(int id, String nombre, int capacidad, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public int compareTo(NaveEspacial otra) {
        return Integer.compare(this.id, otra.id);
    }

    @Override
    public String toString() {
        return "NaveEspacial{id=" + id +
                ", nombre='" + nombre + '\'' +
                ", capacidad=" + capacidad +
                ", categoria=" + categoria + '}';
    }

    public String toCSV() {
        return id + "," + nombre + "," + capacidad + "," + categoria;
    }

    public static NaveEspacial fromCSV(String lineaCSV) {
        String[] datos = lineaCSV.split(",");
        return new NaveEspacial(
                Integer.parseInt(datos[0]),
                datos[1],
                Integer.parseInt(datos[2]),
                Categoria.valueOf(datos[3])
        );
    }
}
