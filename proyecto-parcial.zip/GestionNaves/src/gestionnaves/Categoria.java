package gestionnaves;

public enum Categoria {
    CIENTIFICA,
    TRANSPORTE,
    MILITAR
}
