package gestionnaves;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", 50, Categoria.CIENTIFICA));
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", 3, Categoria.TRANSPORTE));
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", 1, Categoria.MILITAR));
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", 2, Categoria.MILITAR));
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", 100, Categoria.CIENTIFICA));

            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.paraCadaElemento(System.out::println);

            System.out.println("\nNaves de la categoria MILITAR:");
            inventarioNaves.filtrar(nave -> nave.getCategoria() == Categoria.MILITAR)
                    .forEach(System.out::println);

            System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
            inventarioNaves.filtrar(nave -> nave.getNombre().contains("Falcon"))
                    .forEach(System.out::println);

            System.out.println("\nNaves ordenadas de manera natural (por id):");
            inventarioNaves.ordenar();
            inventarioNaves.paraCadaElemento(System.out::println);

            System.out.println("\nNaves ordenadas por nombre:");
            inventarioNaves.ordenar((n1, n2) -> n1.getNombre().compareTo(n2.getNombre()));
            inventarioNaves.paraCadaElemento(System.out::println);

            String rutaCSV = "src/gestionnaves/naves.csv";
            inventarioNaves.guardarEnCSV(rutaCSV);
            System.out.println("Archivo CSV guardado en: " + rutaCSV);

            Inventario<NaveEspacial> inventarioCargadoCSV = new Inventario<>();
            inventarioCargadoCSV.cargarDesdeCSV(rutaCSV, NaveEspacial::fromCSV);
            System.out.println("\nNaves cargadas desde archivo CSV:");
            inventarioCargadoCSV.paraCadaElemento(System.out::println);

        } catch (IOException e) {
            System.err.println("Error de IO: " + e.getMessage());
        }
    }
}
