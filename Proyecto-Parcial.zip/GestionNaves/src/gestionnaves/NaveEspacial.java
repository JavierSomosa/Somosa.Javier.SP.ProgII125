package gestionnaves;

import java.io.Serializable;

public class NaveEspacial implements Serializable, Comparable<NaveEspacial> {
    private int id;
    private String nombre;
    private int capacidad;
    private Categoria categoria;

    public NaveEspacial(int id, String nombre, int capacidad, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public int compareTo(NaveEspacial otra) {
        return Integer.compare(this.id, otra.id);
    }

    @Override
    public String toString() {
        return "NaveEspacial{id=" + id +
                ", nombre='" + nombre + '\'' +
                ", capacidad=" + capacidad +
                ", categoria=" + categoria + '}';
    }

    public String toCSV() {
        return id + "," + nombre + "," + capacidad + "," + categoria;
    }

    public static NaveEspacial fromCSV(String linea) {
        String[] partes = linea.split(",");
        int id = Integer.parseInt(partes[0].trim());
        String nombre = partes[1].trim();
        int capacidad = Integer.parseInt(partes[2].trim());
        Categoria categoria = Categoria.valueOf(partes[3].trim().toUpperCase());
        return new NaveEspacial(id, nombre, capacidad, categoria);
    }
}
